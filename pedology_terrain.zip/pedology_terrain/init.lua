
minetest.register_abm({
    nodenames = {"default:dirt"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:silt_medium_0"})
    end,
})


minetest.register_abm({
    nodenames = {"default:dirt"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:silt_fine_0"})
    end,
})


minetest.register_abm({
    nodenames = {"default:dirt"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:silt_coarse_0"})
    end,
})


minetest.register_abm({
    nodenames = {"default:sand"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:sand_coarse_0"})
    end,
})

minetest.register_abm({
    nodenames = {"default:sand"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:sand_medium_0"})
    end,
})

minetest.register_abm({
    nodenames = {"default:sand"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:sand_fine_0"})
    end,
})

minetest.register_abm({
    nodenames = {"default:clay"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:clay_0"})
    end,
})

minetest.register_abm({
    nodenames = {"default:gravel"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:gravel_coarse_0"})
    end,
})

minetest.register_abm({
    nodenames = {"default:gravel"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:gravel_medium_0"})
    end,
})

minetest.register_abm({
    nodenames = {"default:gravel"},
     -- Added "group:icemaker" and snowbrick. ~ LazyJ
    neighbors = {"air", "group:crumbly", "group:cracky"},
    interval = 1,
    chance = 10,
    action = function(pos, node, active_object_count, active_object_count_wider)
		minetest.add_node(pos,{name="pedology:gravel_fine_0"})
    end,
})



